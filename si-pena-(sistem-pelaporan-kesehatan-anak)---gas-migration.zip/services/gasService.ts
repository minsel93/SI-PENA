/**
 * gasService.ts - Integrated with Google Apps Script
 */

declare const google: any;

export const gasService = {
  /**
   * Wraps google.script.run in a Promise
   */
  async callServer(functionName: string, ...args: any[]): Promise<any> {
    return new Promise((resolve, reject) => {
      if (typeof google === 'undefined' || !google.script || !google.script.run) {
        console.warn(`google.script.run is not available. Mocking ${functionName}...`);
        // Mocking for local development
        setTimeout(() => resolve({ success: true, mock: true }), 500);
        return;
      }

      google.script.run
        .withSuccessHandler((result: any) => resolve(result))
        .withFailureHandler((error: any) => reject(error))
        [functionName](...args);
    });
  },

  async submitData(formType: string, data: any) {
    try {
      const payload = {
        sheetName: formType,
        action: 'append',
        data: data
      };
      return await this.callServer('submitData', payload);
    } catch (error) {
      console.error('GAS Submission Error:', error);
      throw error;
    }
  },

  async getRecords(formType: string) {
    try {
      return await this.callServer('getRecords', formType);
    } catch (error) {
      console.error('GAS Fetch Error:', error);
      return [];
    }
  }
};
